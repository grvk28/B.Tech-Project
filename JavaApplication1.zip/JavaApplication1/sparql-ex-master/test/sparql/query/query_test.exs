defmodule SPARQL.QueryTest do
  use ExUnit.Case
  doctest SPARQL.Query

end
