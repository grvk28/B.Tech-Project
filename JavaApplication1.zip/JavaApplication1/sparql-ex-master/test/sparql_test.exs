defmodule SPARQLTest do
  use ExUnit.Case
  doctest SPARQL

end
