use Mix.Config

config :rdf,
  default_base_iri: "http://example.com/base/"
