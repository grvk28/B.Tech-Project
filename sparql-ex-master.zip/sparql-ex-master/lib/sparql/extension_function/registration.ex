import ProtocolEx

defprotocol_ex SPARQL.ExtensionFunction.Registration do
  def extension_function(name), do: nil
end
